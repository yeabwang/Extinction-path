# IT-276
2d game dev
sdl-c
megaman esque game
![github-small](screenshots/Movies%20%26%20TV%207_11_2020%207_02_44%20PM.png)
![github-small](screenshots/Movies%20%26%20TV%207_11_2020%207_02_50%20PM.png)
![github-small](screenshots/Movies%20%26%20TV%207_11_2020%207_03_11%20PM.png)
![github-small](screenshots/Movies%20%26%20TV%207_11_2020%207_03_38%20PM.png)
![github-small](screenshots/Movies%20%26%20TV%207_11_2020%207_03_30%20PM.png)
![github-small](screenshots/Movies%20%26%20TV%207_11_2020%207_02_51%20PM.png)
